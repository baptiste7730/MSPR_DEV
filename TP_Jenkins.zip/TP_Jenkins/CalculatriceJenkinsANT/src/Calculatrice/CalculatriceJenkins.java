/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Calculatrice;

/**
 *
 * @author ES52281931
 */
public class CalculatriceJenkins {
    public int addition(int a, int b){
        return a + b;
    }

    public int soustraction(int a, int b){
        return a - b;
    }

    public int multiplication(int a, int b){
        return a * b;
    }

    public int division(int a, int b){
        return a / b;
    }
}
